def module1():
    name=input("Please Enter yopur name")
    print("hello",name)
    return